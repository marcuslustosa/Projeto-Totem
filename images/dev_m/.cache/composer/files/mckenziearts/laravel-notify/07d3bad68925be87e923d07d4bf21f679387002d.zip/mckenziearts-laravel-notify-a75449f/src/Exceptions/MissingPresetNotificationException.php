<?php

namespace Mckenziearts\Notify\Exceptions;

use Exception;

class MissingPresetNotificationException extends Exception
{
}
